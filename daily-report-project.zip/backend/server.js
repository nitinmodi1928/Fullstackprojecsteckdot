const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/reportsDB");

const reportSchema = new mongoose.Schema({
  name: String,
  task: String,
  hours: Number,
  date: String
});

const Report = mongoose.model("Report", reportSchema);

app.post("/add-report", async (req, res) => {
  const report = new Report(req.body);
  await report.save();
  res.send("Report Added");
});

app.get("/reports", async (req, res) => {
  const data = await Report.find();
  res.json(data);
});

app.get("/reports/:date", async (req, res) => {
  const data = await Report.find({ date: req.params.date });
  res.json(data);
});

app.listen(5000, () => console.log("Server running on 5000"));
